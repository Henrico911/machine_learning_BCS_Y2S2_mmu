import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt

# ---------------------------------------
# Sigmoid Function
# ---------------------------------------
# Converts a number (z) into a probability between 0 and 1
# Formula: σ(z) = 1 / (1 + e^(-z))
def sigmoid(z):
    z = np.clip(z, -500, 500)  # Limits z to avoid overflow errors
    return 1 / (1 + np.exp(-z))

# ---------------------------------------
# Logistic Regression Class
# ---------------------------------------
class LogisticRegression:
    def __init__(self, learning_rate=0.01, num_iterations=2000, regularization=0.1):
        # learning_rate: How big each step is during training
        # num_iterations: How many times to update the weights
        # regularization: Penalty to prevent weights from getting too large (L2)
        self.learning_rate = learning_rate
        self.num_iterations = num_iterations
        self.regularization = regularization
        self.theta = None  # Weights (to be learned)
        self.scaler = StandardScaler()  # Tool to standardize data
        self.cost_history = []  # Tracks cost over time

    def fit(self, X, y):
        # Trains the model using the input data (X) and labels (y)
        X_scaled = self.scaler.fit_transform(X)
        
        # Add a column of 1s for the bias term (intercept)
        X_b = np.c_[np.ones(X_scaled.shape[0]), X_scaled]
        
        # Initialize weights to zeros
        self.theta = np.zeros(X_b.shape[1])
        
        # Gradient Descent - Update weights to minimize cost
        for i in range(self.num_iterations):
            # Predict probabilities using current weights
            h = sigmoid(np.dot(X_b, self.theta))
            
            # Calculate cost (log loss) with a small epsilon to avoid log(0)
            # Cost = -1/m * [sum(y*log(h) + (1-y)*log(1-h))] + regularization term
            epsilon = 1e-10
            log_loss = (-1/len(y)) * (np.dot(y, np.log(h + epsilon)) + 
                                     np.dot(1 - y, np.log(1 - h + epsilon)))
            # Add L2 regularization penalty (skip bias term)
            reg_term = (self.regularization / (2 * len(y))) * np.sum(self.theta[1:]**2)
            cost = log_loss + reg_term
            self.cost_history.append(cost)
            
            # Calculate gradient (how much to adjust weights)
            gradient = (1/len(y)) * np.dot(X_b.T, (h - y))
            # Add regularization to all but bias term
            gradient[1:] += (self.regularization / len(y)) * self.theta[1:]
            
            # Update weights: Take a step in the opposite direction of gradient
            self.theta -= self.learning_rate * gradient
            
            # Show progress every 200 iterations
            if i % 200 == 0:
                print(f"Iteration {i}: Cost = {cost:.4f}")
        
        return self

    def predict_proba(self, X):
        # Predicts probabilities for new data
        X_scaled = self.scaler.transform(X)  # Standardize new data
        X_b = np.c_[np.ones(X_scaled.shape[0]), X_scaled]  # Add bias term
        return sigmoid(np.dot(X_b, self.theta))  # Return probabilities

    def predict(self, X, threshold=0.5):
        # Predicts 0 or 1 based on a threshold (default 0.5)
        probs = self.predict_proba(X)
        return (probs >= threshold).astype(int)

# Load dataset
data = pd.read_csv('diabetes.csv')
X = data.drop('Outcome', axis=1).values  # Features
y = data['Outcome'].values               # Labels (0 = no diabetes, 1 = yes)

# Split into training (80%) and testing (20%) sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train and Test Model
model = LogisticRegression(learning_rate=0.01, num_iterations=2000, regularization=0.1)
model.fit(X_train, y_train)

# Make predictions on test data
y_test_pred = model.predict(X_test)
y_test_prob = model.predict_proba(X_test)

# Calculate accuracy (percentage of correct predictions)
accuracy = np.mean(y_test_pred == y_test) * 100
print(f"\n=== Model Performance ===")
print(f"Test Accuracy: {accuracy:.2f}%")

# Show predictions for all test samples
print("\n=== Predictions on Test Data (All Samples) ===")
print("Index | True | Predicted | Probability")
print("-" * 40)

# logic to print the table
for i in range(len(y_test)):  # Loop through all test samples
    print(f"{i:^5} | {y_test[i]:^4} | {y_test_pred[i]:^9} | {y_test_prob[i]:.4f}")

# ---------------------------------------
# Plot Cost Convergence
# ---------------------------------------
# Plot how the cost decreases over iterations
plt.figure(figsize=(8, 5))
plt.plot(range(model.num_iterations), model.cost_history, label='Log Loss (Cost)', color='b')
plt.xlabel('Iteration')          
plt.ylabel('Log Loss (Cost)')     
plt.title('Cost Function Convergence')  
plt.grid(True, linestyle='--', alpha=0.7) 
plt.legend()                      
plt.show()