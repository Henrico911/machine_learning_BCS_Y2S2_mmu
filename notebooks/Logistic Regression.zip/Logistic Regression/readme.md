This includes 
    >> The mathematical explanation of the logistic regression  (logistic_regression.pdf)
    >> Code implementation using python   (Logistic.py)